#include <Arduino.h>
#include <Oldgauge.h>
#include <Arduino_JSON.h>
#include <HTTPClient.h>
#include "internal.h"

#define ERROR_DELAY 5000 // ms
#define POLL_DELAY 5000  // ms

const String URL = "https://u4rurbd9ic.execute-api.ap-southeast-1.amazonaws.com/staging/metrics";

String mockReply(JSONVar request);

// void InitialiseOldgauge() {
//   Serial.println("InitialiseOldgauge()");
// }

Oldgauge::Oldgauge(bool useMockData, int pinConfigButton, int pinPairingLed, int pinErrorLed)
{
  _useMockData = useMockData;
  _pinConfigButton = pinConfigButton;
  _pinPairingLed = pinPairingLed;
  _pinErrorLed = pinErrorLed;

  if (_pinConfigButton > 0) {
    pinMode(_pinConfigButton, INPUT_PULLUP);
  }
  if (_pinPairingLed > 0) {
    pinMode(_pinPairingLed, OUTPUT);
  }
  if (_pinErrorLed > 0) {
    pinMode(_pinErrorLed, OUTPUT);
  }

  initialiseCaptivePortal();
};

void Oldgauge::errorBlink(int num)
{
  // Serial.print("errorBlink()");
  // Serial.println(num);

  if (_pinPairingLed > 0 && _pinErrorLed > 0) {
    digitalWrite(_pinPairingLed, LOW);
    for (int i = 0; i < num; i++)
    {
      digitalWrite(_pinErrorLed, HIGH); // Error LED
      delay(500);
      digitalWrite(_pinErrorLed, LOW); // Error LED
      delay(500);
    }
    delay(ERROR_DELAY);
  }
}

void Oldgauge::addLayout(OG_Layout *layout)
{
  if (_numLayouts >= OG_MAX_LAYOUTS)
  {
    throw "Exceeded the maximum number of layouts";
  }
  _layouts[_numLayouts++] = layout;
}

JSONVar Oldgauge::toJSONVar()
{
  // Serial.println("Oldgauge::toJSONVar()");

  JSONVar myObject;

  myObject["clusterId"] = "6b6081f3-962f-47aa-af38-64589d72aab5"; // ZZZZ
  myObject["passphrase"] = "abc";
  // myObject["pin"] = "12345"; // Optional ZZZZZ
  myObject["selectedChannel"] = _selectedChannel;
  myObject["macaddr"] = getMacaddr();

  // myObject["capabilities"] = "{\"meter1\":{\"type\":\"meter\",\"max\":100},\"led1\":{\"type\":\"led\",\"color\":\"red\"}}";
  // myObject["capabilities"] = "{ }";
  // Serial.println(myObject["capabilities"]);
  myObject["device_clusterId"] = "";

  for (int i = 0; i < _numLayouts; i++)
  {
    String name = _layouts[i]->getName();
    JSONVar layout = _layouts[i]->toJSONVar();
    myObject["layouts"][name] = layout;
  }
  return myObject;
  // return JSON.stringify(myObject);
}

int Oldgauge::getSelectedChannel()
{
  return _selectedChannel;
}

int Oldgauge::getDisplayedChannel()
{
  return _displayedChannel;
}

int Oldgauge::numChannels()
{
  // Serial.println("Oldgauge::numChannels()");
  // Serial.print("_displayedData=");
  // Serial.println(_displayedData);
  // JSONVar channels = _displayedData["channels"];
  // Serial.print("channels=");
  // Serial.println(channels);
  // int length = channels.length();
  // Serial.print("length=");
  // Serial.println(length);
  // Serial.println("^^^^^^\n");

  return _displayedData["channels"].length();
}

String Oldgauge::channelLabel(int channel)
{
  return _displayedData["channels"][channel]["label"];
}

void Oldgauge::setSelectedChannel(int channel)
{
  if (channel >= 0 && channel < numChannels())
  {
    _selectedChannel = channel;
    String label = channelLabel(channel);
    Serial.print("Set channel to " + String(channel) + "  (" + label + ")");
  }
}

void Oldgauge::channelUp() {
  Serial.println("channelUp()");
  _selectedChannel = (_selectedChannel + 1) % numChannels();
}

void Oldgauge::channelDown() {
  Serial.println("channelDown()");
  _selectedChannel--;
  if (_selectedChannel < 0) {
    _selectedChannel = numChannels() - 1;
  }
}


void Oldgauge::inTheLoop()
{
  // Serial.println("Oldgauge::inTheLoop()");
  Serial.println("------------------------------------------------------------------");

  // Get the message to send to the server.
  JSONVar request = this->toJSONVar();
  JSONVar sendJson = JSON.stringify(request);
  Serial.print("WILL SEND ");
  Serial.print(sendJson);
  Serial.println();

  // Set the LEDs
  // digitalWrite(LED_BUILTIN, HIGH);
  if (_pinPairingLed > 0) {
    digitalWrite(_pinPairingLed, HIGH);
  }
  if (_pinErrorLed) {
    digitalWrite(_pinErrorLed, LOW);
  }

  // Call the server.
  String payload;
  if (_useMockData)
  {
    payload = mockReply(request);
  }
  else
  {
    HTTPClient http;
    http.begin(URL.c_str());
    Serial.print("URL=");
    Serial.println(URL);
    int httpResponseCode = http.PUT(sendJson);
    Serial.print("httpResponseCode=");
    Serial.println(httpResponseCode);
    if (httpResponseCode != 200)
    {
      //  Error connecting to the server.
      Serial.print("Error code: ");
      Serial.println(httpResponseCode);
      // digitalWrite(LED_BUILTIN, LOW);
      if (_pinPairingLed) {
        digitalWrite(_pinPairingLed, LOW);
      }
      String payload = http.getString();
      Serial.print("payload=");
      Serial.println(payload);
      // http.errorToString
      http.end();
      errorBlink(3);
      return;
    }
    payload = http.getString();
    http.end();
  }

  // Reset the LEDs
  // digitalWrite(LED_BUILTIN, LOW);
  if (_pinPairingLed) {
    digitalWrite(_pinPairingLed, LOW);
  }

  // Parse the JSON response
  Serial.print("RESPONSE=");
  Serial.println(payload);
  JSONVar myObject = JSON.parse(payload);
  if (JSON.typeof(myObject) == "undefined")
  {
    Serial.println("Parsing input failed!");
    errorBlink(2);
    return;
  }

  // Find the Layout specified by the server.
  // OG_Layout *currentLayout = _layouts[0];
  // if (myObject.hasOwnProperty("layout"))
  // {
  //   String layoutName = myObject["layout"];
  //   Serial.print("layoutName=");
  //   Serial.println(layoutName);
  //   for (int i = 0; i < _numLayouts; i++)
  //   {
  //     if (_layouts[i]->getName() == layoutName)
  //     {
  //       Serial.println("Found layout");
  //       currentLayout = _layouts[i];
  //       break;
  //     }
  //   }
  // }

  // Save the channel list, if provided.
  // if (myObject.hasOwnProperty("channels"))
  // {
  //   // Serial.println("Have channels");
  //   JSONVar channels = myObject["channels"];

  //   _numChannels = channels.length();
  //   if (_numChannels > OG_MAX_CHANNELS)
  //   {
  //     _numChannels = OG_MAX_CHANNELS;
  //   }
  //   for (int i = 0; i < _numChannels; i++)
  //   {
  //     String channelName = channels[i]["label"];
  //     _channels[i] = channelName;
  //   }
  //   // Serial.print("_channels=");
  //   // Serial.println(_channels);
  // }

  // Remember what channel we are displaying
  if (myObject.hasOwnProperty("displayChannel"))
  {
    _displayedChannel = myObject["displayChannel"];
  }

  // Check the metrics
  // if (myObject.hasOwnProperty("metrics"))
  // {
  //   JSONVar metrics = myObject["metrics"];
  //   Serial.println(metrics);

  //   if (metrics.hasOwnProperty("meter"))
  //   {
  //     JSONVar meter = metrics["meter"];
  //     Serial.println(meter);

  //     int myValue = meter["value"];
  //     // Serial.print("myValue=");
  //     // Serial.println(myValue);
  //     // Serial.println(JSON.typeof(myValue));
  //     // Set the meter position
  //     Serial.printf("Meter value is %d\n", myValue);

  //     ledcWrite(0, myValue);
  //     // dacWrite(MYPIN_METER, myValue);
  //     // analogWrite(MYPIN_ENTER_CONFIG_MODE);
  //     delay(POLL_DELAY);
  //   }
  //   else
  //   {
  //     // The meter value is missing from the JSON.
  //     Serial.println("Parsing value failed!");
  //     errorBlink(5);
  //     return;
  //   }
  // }

  _displayedData = myObject;


  // Update our clusterId, if it's changed.
  // ZZZZ

  // Find the current channel and display it's layout
  showChannel(_displayedChannel);

}

void Oldgauge::showChannel(int channelNo) {

  // Get the channel data
  JSONVar channelData = _displayedData["channels"][channelNo];
  // Serial.print("channelData=");
  // Serial.println(channelData);

  // Should be something like this
  //   "{"
  // "    \"label\":\"Project Y\","
  // "    \"data\": {" // subchannels
  // "        \"cpu\": {"
  // "            \"label\": \"CPU (%)\","
  // "            \"layout\": \"meter\","
  // "            \"value\": \"" + String(counterV2) + "\","
  // "            \"min\": 0,"
  // "            \"max\": 100"
  // "        },"
  // "        \"memory\": {"
  // "            \"label\": \"Memory (%)\","
  // "            \"layout\": \"meter\","
  // "            \"value\": \"" + String(counterV1) + "\","
  // "            \"min\": 0,"
  // "            \"max\": 100"
  // "        }"
  // "    }"
  // "},"

  String label = channelData["label"];
  String layout = channelData["layout"];
  // Serial.println("----> channel '" + label + "' using layout '" + layout + "'");
  // Serial.println();

  // Find the layout
  for (int i = 0; i < _numLayouts; i++) {
    // String l = _layouts[i]->getName();
    // Serial.println("  ->Checking layout " + l);
    if (_layouts[i]->getName() == layout) {
      // _layouts[i]->updateFromServer(channelData);
      // Serial.println("FOUND THE LAYOUT");
      _layouts[i]->show(this, channelData);
      break;
    }
  }


  //   if (currentLayout == null)
  // {
  //   Serial.println("Layout not specified in the reply - not displaying");
  //   return;
  // }

  // // Set the values for the various outputs.
  // JSONVar values = myObject["values"];
  // if (JSON.typeof(values) == "object")
  // {
  //   // Serial.println("Loop through the devices, under values.");
  //   currentLayout->updateFromServer(values);
  // }
  // currentLayout->show(this);

}

int counterV1 = 139;
int counterV2 = 99;
String mockReply(JSONVar request)
{
  delay(1500);

  // Get the selected channel from the request
  String json = request;
  int selectedChannel = request["selectedChannel"];

  // Create some mock data
  counterV1 = (counterV1 + 27) % 255;
  counterV2 = (counterV2 - 39);
  if (counterV2 < 0)
  {
    counterV2 += 255;
  }

  int displayedChannel = selectedChannel;
  const String data = "{"
                      "\"clusterId\":\"6b6081f3-962f-47aa-af38-64589d72aab5\","
                      "\"displayChannel\":" + String(displayedChannel) + ","
                      "\"email\":\"philcal@mac.com\","
                      "\"channels\":["
                      "{"
                      "    \"label\":\"Project X\","
                      "    \"layout\": \"layout1\","
                      "    \"data\": {" // subchannels
                      "        \"cpu\": {"
                      "            \"label\": \"CPU (%)\","
                      "            \"style\": \"default\","
                      "            \"value\": " + String(counterV1) + ","
                      "            \"min\": 0,"
                      "            \"max\": 255"
                      "        },"
                      "        \"memory\": {"
                      "            \"label\": \"Memory (%)\","
                      "            \"style\": \"vertical\","
                      "            \"value\": " + String(counterV2) + ","
                      "            \"min\": 0,"
                      "            \"max\": 255"
                      "        }"
                      "    }"
                      "},"
                      "{"
                      "    \"label\":\"Project Y\","
                      "    \"layout\": \"layout1\","
                      "    \"data\": {" // subchannels
                      "        \"cpu\": {"
                      "            \"label\": \"CPU (%)\","
                      "            \"value\": " + String(counterV2) + ","
                      "            \"min\": 0,"
                      "            \"max\": 255"
                      "        },"
                      "        \"memory\": {"
                      "            \"label\": \"Memory (%)\","
                      "            \"value\": " + String(counterV1) + ","
                      "            \"min\": 0,"
                      "            \"max\": 255"
                      "        }"
                      "    }"
                      "}"
                      "]"
                      "}";
                      



                      // "\"meter\":{"
                      // "\"cpu\":{\"label\":\"CPU (%)\",\"value\":" + String(counterV1) + ",\"min\":0,\"max\":100},"
                      // "\"memory\":{\"label\":\"Memory (%)\",\"value\":" + String(counterV2) + ",\"min\":0,\"max\":100}"
                      // "}"
                      // "},"
                      // "\"channels\":[\"Project X\",\"PIQ\",\"Advisor-e\",\"Project Y\",\"Project Z\"]"
                      // "}";
  return data;
}


bool Oldgauge::enterConfigModeIfTilted() {
  if (_pinConfigButton < 0) {
    return false;
  }

  // Check for the RESET pin being set.
  int value = digitalRead(_pinConfigButton);
  // Serial.printf("Tilt=%d\n", value);

  if (value != _previousResetPin) {
    _previousResetPin = value;
    if (value == LOW) {
      Serial.printf("Device tilted or pairing button pressed - entering pairing mode\n");
      // Just entered reset mode.
      if (_pinPairingLed > 0) {
        digitalWrite(_pinPairingLed, HIGH);
      }
      if (_pinErrorLed > 0) {
        digitalWrite(_pinErrorLed, HIGH);
      }
      Serial.println("Enter wifi config mode (from loop)");
      // WiFiManager wm;
      // wm.resetSettings();
      // wm.setConfigPortalTimeout(timeout);
      
      // Fix for Android devices not finding the captive portal
      // See https://github.com/tzapu/WiFiManager/issues/841
      // wm.setAPStaticIPConfig(IPAddress(8,8,8,8), IPAddress(8,8,8,8), IPAddress(255,255,255,0));

      bool res = wm.startConfigPortal("Oldgauge2");

      saveConfigIfNecessary();

      if (res) {
        Serial.println("Connected, yeey!");
        if (_pinPairingLed > 0) {
          digitalWrite(_pinPairingLed, LOW);
        }
        if (_pinErrorLed > 0) {
          digitalWrite(_pinErrorLed, LOW);
        }
      } else {
        Serial.println("failed to connect");
        //ZZZ Blink LEDS?
        delay(3000);
        ESP.restart();
        delay(5000);
        return true;
      }
    }//- value == LOW
  }//- value != _previousResetPin
  return false;
}
