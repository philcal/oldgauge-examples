#include <Arduino.h>
#include <Oldgauge.h>

OG_ChannelSelectionLEDs::OG_ChannelSelectionLEDs (
  Oldgauge* cluster,
  String name,
  int pinLed1, int pinLed2, int pinLed3, int pinLed4, int pinLed5, int pinLed6

  )  : OG_OutputDevice{ name } {
  // Serial.print("OG_ChannelSelectionLEDs::OG_ChannelSelectionLEDs(");
  // Serial.print(name);
  // Serial.println();
  _cluster = cluster;
  _pinLed1 = pinLed1;
  _pinLed2 = pinLed2;
  _pinLed3 = pinLed3;
  _pinLed4 = pinLed4;
  _pinLed5 = pinLed5;
  _pinLed6 = pinLed6;
  // _name = name;


  if (pinLed1 > 0) {
    pinMode(pinLed1, OUTPUT);
  }
  if (pinLed1 > 0) {
    pinMode(pinLed2, OUTPUT);
  }
  if (pinLed1 > 0) {
    pinMode(pinLed3, OUTPUT);
  }
  if (pinLed1 > 0) {
    pinMode(pinLed4, OUTPUT);
  }
  if (pinLed1 > 0) {
    pinMode(pinLed5, OUTPUT);
  }
  if (pinLed1 > 0) {
    pinMode(pinLed6, OUTPUT);
  }

}


JSONVar OG_ChannelSelectionLEDs::toJSONVar() {
  JSONVar me;
  // me["name"] = _name;
  // me["g1"]["type"] = "int";
  // me["g1"]["min"] = 0;
  // me["g1"]["max"] = 255;
  return me;
}

void OG_ChannelSelectionLEDs::updateFromServer(JSONVar data) {
  // Serial.printf("OG_ChannelSelectionLEDs::updateFromServer(%s)\n", _name.c_str());
  // Nothing to do here
}

void OG_ChannelSelectionLEDs::show(Oldgauge* cluster, OG_Layout* layout, JSONVar data) {
  // Serial.printf("OG_ChannelSelectionLEDs::show(%s)\n", _name.c_str());
  // Serial.printf("  channel=%d\n", _selector->currentChannel());

  int selectedChannel = _cluster->getSelectedChannel();
  int displayedChannel = _cluster->getDisplayedChannel();
  bool same = (selectedChannel == displayedChannel);

  digitalWrite(_pinLed1, (selectedChannel == 0 || (same && selectedChannel >= 0)) ? HIGH : LOW);
	digitalWrite(_pinLed2, (selectedChannel == 1 || (same && selectedChannel >= 1)) ? HIGH : LOW);
	digitalWrite(_pinLed3, (selectedChannel == 2 || (same && selectedChannel >= 2)) ? HIGH : LOW);
	digitalWrite(_pinLed4, (selectedChannel == 3 || (same && selectedChannel >= 3)) ? HIGH : LOW);
	digitalWrite(_pinLed5, (selectedChannel == 4 || (same && selectedChannel >= 4)) ? HIGH : LOW);
	digitalWrite(_pinLed6, (selectedChannel == 5 || (same && selectedChannel >= 5)) ? HIGH : LOW);
}

