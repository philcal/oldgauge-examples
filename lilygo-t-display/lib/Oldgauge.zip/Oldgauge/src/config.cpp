/*
 *  Store config information in Flash memory, as a JSON file.
 */
#include <Arduino.h>
#include <Arduino_JSON.h>
// #include "myFirmware.h"
#include "internal.h"


char param_passphrase[50] = "";
char param_pin[10] = "";
char param_clusterID[128] = "";


//flag for saving data
bool shouldSaveConfig = false;

//callback notifying us of the need to save config
void rememberToSaveConfig() {
  Serial.println("rememberToSaveConfig() - SETTING FLAG TO SAVE THE CONFIG");
  shouldSaveConfig = true;
}

void saveConfigIfNecessary() {
  // Save the custom parameters to File System
  if (shouldSaveConfig) {
    Serial.println("saving config");
    saveConfig();

  } else {
    Serial.println("Do not save config");
  }
}


void loadConfig() {

  /*
   *  Read configuration from Filesystem
   */
  Serial.println("mounting FS...");
  if (SPIFFS.begin(true)) { // format on fail
    Serial.println("mounted file system");
    if (SPIFFS.exists("/config.json")) {
      //file exists, reading and loading
      Serial.println("reading config file");
      File configFile = SPIFFS.open("/config.json", "r");
      if (configFile) {
        Serial.println("opened config file");
        size_t size = configFile.size();
        // Allocate a buffer to store contents of the file.
        std::unique_ptr<char[]> buf(new char[size]);

        configFile.readBytes(buf.get(), size);
        // Serial.println(buf.get());

        JSONVar json = JSON.parse(buf.get());
Serial.println("json type is");
Serial.println(JSON.typeof(json));
        if (JSON.typeof(json) != "undefined") {
          Serial.println("\nparsed json");
          strcpy(param_passphrase, json["passphrase"]);
          strcpy(param_pin, json["pin"]);
          strcpy(param_clusterID, json["clusterID"]);
        } else {
          Serial.println("failed to load json config");
        }
        configFile.close();
      } else {
        Serial.println("Did not open config file");
      }
    } else {
      Serial.println("Config file does not exist");
    }
  } else {
    Serial.println("failed to mount FS");
  }
  //end read

  // If we don't have a pin, generate one now.
  // strcpy(param_pin, "");
  if (param_pin == null || strlen(param_pin) == 0) {
    // if analog input pin 0 is unconnected, random analog
    // noise will cause the call to randomSeed() to generate
    // different seed numbers each time the sketch runs.
    // randomSeed() will then shuffle the random function.
    randomSeed(analogRead(0));
    // 
    long newPIN1 = random(0, 999);
    long newPIN2 = random(0, 999);
    Serial.print("New PIN is: ");
    Serial.println(newPIN1);
    Serial.println(newPIN2);
    sprintf(param_pin, "%03ld-%03ld", newPIN1, newPIN2);
    Serial.println(param_pin);
  }


  Serial.println("The initial values are: ");
  Serial.println("\tpassphrase: " + String(param_passphrase));
  Serial.println("\tPIN: " + String(param_pin));
  Serial.println("\tclusterID: " + String(param_clusterID));
}


void saveConfig() {
  Serial.println("saveConfig()");

  // Read updated parameters
  strcpy(param_passphrase, passphrase_text_box.getValue());
  strcpy(param_pin, pin_text_box.getValue());
  strcpy(param_clusterID, clusterID_text_box.getValue());
  Serial.println("The values after entry are: ");
  Serial.println("\tpassphrase: " + String(param_passphrase));
  Serial.println("\tPIN: " + String(param_pin));
  Serial.println("\tclusterID: " + String(param_clusterID));

  // Save the values to the file system.
  JSONVar json;
  // json["passphrase"] = getParam("passphrase");
  // json["clusterID"] = getParam("clusterID");
  // json["pin"] = getParam("pin");
  json["passphrase"] = param_passphrase;
  json["pin"] = param_pin;
  json["clusterID"] = param_clusterID;

  File configFile = SPIFFS.open("/config.json", "w");
  if (configFile) {
    Serial.println("New config is: ");
    json.printTo(Serial);
    Serial.println();
    json.printTo(configFile);
    configFile.close();
  } else {
    Serial.println("failed to open config file for writing");
  }
}
