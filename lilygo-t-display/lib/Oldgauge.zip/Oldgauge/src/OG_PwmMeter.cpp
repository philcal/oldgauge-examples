#include <Arduino.h>
#include <Oldgauge.h>




OG_PwmMeter::OG_PwmMeter(String name, int pwmPin) : OG_OutputDevice(name) {
  // Serial.print("OG_PwmMeter::OG_PwmMeter()");
  _name = name;
  _pwmPin = pwmPin;

  // Set up the meter to use PWM
  // Configuration of channel 0 with the chosen frequency and resolution
  ledcSetup(_pwmChannel, _frequence, _resolution);

  // Assigns the PWM channel to pin 23
  ledcAttachPin(_pwmPin, _pwmChannel);

  // Create the selected output voltage
  // ledcWrite(pwmChannel, 255);

}


JSONVar OG_PwmMeter::toJSONVar() {
  JSONVar me;
  // me["name"] = _name;
  me["v1"]["type"] = "int";
  // me["g1"]["min"] = 0;
  // me["g1"]["max"] = 255;
  return me;
}

// Remove this.
void OG_PwmMeter::updateFromServer(JSONVar data) {
  // Serial.printf("OG_PwmMeter::updateFromServer(%s)\n", _name.c_str());
  return;
}


void OG_PwmMeter::show(Oldgauge* cluster, OG_Layout* layout, JSONVar data) {
  // Serial.printf("OG_PwmMeter::show(%s)\n", _name.c_str());

  JSONVar myData = data["data"];
  JSONVar keys = myData.keys();

  // Lets just show the first data value.
  JSONVar firstMetric = myData[keys[0]];
  String label = firstMetric["label"];
  String style = firstMetric["style"];
  int value = firstMetric["value"];

  Serial.println("SHOWING '" + label + "' AS VALUE " + String(value) + " WITH STYLE " + style);

  // Convert the output to 0 - 255
  //ZZZZ

  // Create the selected output voltage
  ledcWrite(_pwmChannel, value);
}

