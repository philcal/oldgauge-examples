/*
 *  We use WifiManager to provide an Access Point (AP) and captive portal,
 *  so the user can configure the device:
 *    1. Connect to their Wifi router
 *    2. Enter a passphrase for encrypting secrets on the server.
 *    3. Write down a Pairing Code for use in their admin console (oldgauge.com).
 */
#include <Arduino.h>
#include <Arduino_JSON.h>
// #include "myFirmware.h"
#include "internal.h"


// Deprecate these
#define MYPIN_ENTER_CONFIG_MODE 13 // Enter config mode (SP pin)
#define MYPIN_PAIRING_LED 14 // Blue = connect
// #define MYPIN_ERROR_LED 27 // Red = error
#define MYPIN_ERROR_LED 27 // Red = error




// int previousResetPin = HIGH;

WiFiManager wm;
WiFiManagerParameter passphrase_text_box;
WiFiManagerParameter pin_text_box;
WiFiManagerParameter clusterID_text_box;


void initialiseCaptivePortal() {
  // reset settings - wipe stored credentials for testing
  // these are stored by the esp library
  // wm.resetSettings();

  //clean FS, for testing
  // SPIFFS.format();
  loadConfig();


  // Add text boxes for the passphrase, clusterID and PIN
  new (&passphrase_text_box) WiFiManagerParameter("passphrase", "Enter a passphrase", param_passphrase, 50);
  new (&pin_text_box) WiFiManagerParameter("pin", "PIN", param_pin, 10, " readonly");
  new (&clusterID_text_box) WiFiManagerParameter("clusterID", "ClusterID", param_clusterID, 128, " readonly");

  wm.addParameter(&passphrase_text_box);
  wm.addParameter(&pin_text_box);
  wm.addParameter(&clusterID_text_box);

  //set config save notify callback
  wm.setSaveConfigCallback(rememberToSaveConfig);
  // Save even if the wifi config is wrong.
  // See https://github.com/tzapu/WiFiManager#save-settings
  wm.setBreakAfterConfig(true);
  // Save before checking wifi config?
  // See https://forum.arduino.cc/t/wifi-manager-custom-parameters-are-not-saved-in-memory-via-ondemand-portal/921063/7
  // wm.setPreSaveConfigCallback(saveConfigCallback2);

  // custom menu via array or vector
  // 
  // menu tokens, "wifi","wifinoscan","info","param","close","sep","erase","restart","exit" (sep is seperator) (if param is in menu, params will not show up in wifi page!)
  // const char* menu[] = {"wifi","info","param","sep","restart","exit"}; 
  // wm.setMenu(menu,6);
  std::vector<const char *> menu = {"wifi","info","sep","restart","exit", "erase", "close"};
  wm.setMenu(menu);

  // set dark theme
  wm.setClass("invert");


  // wm.setRestorePersistent()

  // Set a static IP address.
  // This is a fix for Android devices not finding the captive portal.
  // See https://github.com/tzapu/WiFiManager/issues/841
  wm.setAPStaticIPConfig(IPAddress(8,8,8,8), IPAddress(8,8,8,8), IPAddress(255,255,255,0));
  // wm.setShowStaticFields(true); // force show static ip fields
  // wm.setShowDnsFields(true);    // force show dns field always

  // wifi scan settings
  // wm.setRemoveDuplicateAPs(false); // do not remove duplicate ap names (true)
  // wm.setMinimumSignalQuality(20);  // set min RSSI (percentage) to show in scans, null = 8%
  // wm.setShowInfoErase(false);      // do not show erase button on info page
  // wm.setScanDispPerc(true);       // show RSSI as percentage not graph icons
  
  // wm.setBreakAfterConfig(true);   // always exit configportal even if wifi save fails


  //set a timeout until configuration portal gets turned off
  //useful to make it all retry or go to sleep
  //in seconds
  //wm.setTimeout(120);
  // wm.setConnectTimeout(20); // how long to try to connect for before continuing
  // wm.setConfigPortalTimeout(30); // auto close configportal after n seconds
  // wm.setCaptivePortalEnable(false); // disable captive portal redirection
  // wm.setAPClientCheck(true); // avoid timeout if client connected to softap

    // Automatically connect using saved credentials,
    // if connection fails, it starts an access point with the specified name ( "AutoConnectAP" ),
    // if empty will auto generate SSID, if password is blank it will be anonymous AP (wm.autoConnect())
    // then goes into a blocking loop awaiting configuration and will return success result

    bool res;
    digitalWrite(MYPIN_PAIRING_LED, HIGH);
    digitalWrite(MYPIN_ERROR_LED, HIGH);
    res = wm.autoConnect("oldgauge");
    // res = wm.startConfigPortal("oldgauge");

    digitalWrite(MYPIN_PAIRING_LED, LOW);
    digitalWrite(MYPIN_ERROR_LED, LOW);
    // res = wm.autoConnect("oldguage","password"); // password protected ap

    if(!res) {
        Serial.println("Failed to connect");
        // ESP.restart();
    } 
    else {
        //if you get here you have connected to the WiFi    
        Serial.println("connected to wifi...");
    }

  saveConfigIfNecessary();
}



// bool enterConfigModeIfTilted() {
//   // Check for the RESET pin being set.
//   int value = digitalRead(MYPIN_ENTER_CONFIG_MODE);
//   // Serial.printf("Tilt=%d\n", value);

//   if (value != previousResetPin) {
//     previousResetPin = value;
//     if (value == LOW) {
//       Serial.printf("Device tilted or pairing button pressed - entering pairing mode\n");
//       // Just entered reset mode.
//       digitalWrite(MYPIN_PAIRING_LED, HIGH);
//       digitalWrite(MYPIN_ERROR_LED, HIGH);
//       Serial.println("Enter wifi config mode (from loop)");
//       // WiFiManager wm;
//       // wm.resetSettings();
//       // wm.setConfigPortalTimeout(timeout);
      
//       // Fix for Android devices not finding the captive portal
//       // See https://github.com/tzapu/WiFiManager/issues/841
//       // wm.setAPStaticIPConfig(IPAddress(8,8,8,8), IPAddress(8,8,8,8), IPAddress(255,255,255,0));

//       bool res = wm.startConfigPortal("Oldgauge2");

//       saveConfigIfNecessary();

//       if (res) {
//         Serial.println("Connected, yeey!");
//         digitalWrite(MYPIN_PAIRING_LED, LOW);
//         digitalWrite(MYPIN_ERROR_LED, LOW);
//       } else {
//         Serial.println("failed to connect");
//         //ZZZ Blink LEDS?
//         delay(3000);
//         ESP.restart();
//         delay(5000);
//         return true;
//       }
//     }//- value == LOW
//   }//- value != previousResetPin
//   return false;
// }

