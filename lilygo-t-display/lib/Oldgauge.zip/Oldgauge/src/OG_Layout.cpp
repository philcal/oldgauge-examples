/*
 *  Layout
 */
#include <Arduino.h>
#include <Oldgauge.h>


OG_Layout::OG_Layout(String name) {
  _name = name;
}

void OG_Layout::addOutputDevice(OG_OutputDevice* device) {
  if (_numOutputs >= OG_MAX_DEVICES) {
    throw "Exceeded the maximum number of devices in a layout";
  }
  _outputs[_numOutputs++] = device;
}

String OG_Layout::getName() {
  return _name;
}

JSONVar OG_Layout::toJSONVar() {
  JSONVar me;
  for (int i = 0; i < _numOutputs; i++) {
    String deviceName = _outputs[i]->getName();
    JSONVar layout = _outputs[i]->toJSONVar();
    me["outputs"][deviceName] = layout;
  }
  return me;
}

// void OG_Layout::updateFromServer(JSONVar data) {
//   // Serial.println("OG_Layout::updateFromServer()");

//   // For each of our displays, see if we have data.
//   // Serial.print("layout=");
//   // Serial.println(_name);
//   // Serial.print(" data=");
//   // Serial.println(JSON.stringify(data));

//       // JSONVar deviceNames = values.keys();
//     // Serial.println(deviceNames);

//   // For each output device, see if we have data.
//   for (int i = 0; i < _numOutputs; i++) {
//     String outputName = _outputs[i]->getName();
//     JSONVar deviceData = data[outputName];
//     if (JSON.typeof(deviceData) == "object") {
//       _outputs[i]->updateFromServer(deviceData);
//     }
//   }

// }


void OG_Layout::show(Oldgauge* cluster, JSONVar data) {
  for (int i = 0; i < _numOutputs; i++) {
    _outputs[i]->show(cluster, this, data);
  }
}
