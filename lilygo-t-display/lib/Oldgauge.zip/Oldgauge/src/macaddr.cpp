#include <Arduino.h>

String getMacaddr() {
  // Get the unique MAC address for this device
  // https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/system/misc_system_api.html#_CPPv425esp_efuse_mac_get_defaultP7uint8_t
  uint8_t macAddress[8];
  
  int ret = esp_efuse_mac_get_default(macAddress);
  // if(ret != ESP_OK){
  //       ESP_LOGE(TAG, "Failed to get base MAC address from EFUSE BLK0. (%s)", esp_err_to_name(ret));
  //       ESP_LOGE(TAG, "Aborting");
  //       abort();
  //   } 
  // Serial.print("MAC Address: ");
  // Serial.print(macAddress[0], HEX);
  // Serial.print(" ");
  // Serial.print(macAddress[1], HEX);
  // Serial.print(" ");
  // Serial.print(macAddress[2], HEX);
  // Serial.print(" ");
  // Serial.print(macAddress[3], HEX);
  // Serial.print(" ");
  // Serial.print(macAddress[4], HEX);
  // Serial.print(" ");
  // Serial.println(macAddress[5], HEX);

  char str[19];
  sprintf(str, "%02x:%02x:%02x:%02x:%02x:%02x",macAddress[0], 
        macAddress[1], macAddress[2], macAddress[3], macAddress[4],macAddress[5]);
  // Serial.printf("MAC is %s\n", str);

  return str;
}