#include <Arduino.h>
#include <Oldgauge.h>
#include <FunctionalInterrupt.h>

RotaryEncoderChannelSelector::RotaryEncoderChannelSelector(
  Oldgauge* cluster,
  int pinSw, int pinClk, int pinDat,
  std::function<void ()> buttonHandler,
  std::function<void ()> rotateHandler
  // int pinLed1, int pinLed2, int pinLed3, int pinLed4, int pinLed5, int pinLed6
) {
  Serial.println("RotaryEncoderChannelSelector::RotaryEncoderChannelSelector()");

  _pinSw = pinSw;
  _pinClk = pinClk;
  _pinDat = pinDat;

  pinMode(pinSw, INPUT_PULLUP);
  pinMode(pinClk, INPUT);
  pinMode(pinDat, INPUT);

  attachInterrupt(_pinSw, buttonHandler, CHANGE);
  attachInterrupt(_pinDat, rotateHandler, CHANGE);


  // Read the initial state of CLK
	_lastStateCLK = digitalRead(pinClk);


  // // We have a problem with attachInterrupt because it expects a regular function,
  // // not a class method. To get arround this we use a "FunctionalInterrupt".
  // // See https://stackoverflow.com/questions/76644826/how-to-use-attachinterrupt-inside-a-class-in-arduino
  // attachInterrupt(pinSw, std::bind(&RotaryEncoderChannelSelector::encoderButtonCallback, this), CHANGE);
  // attachInterrupt(pinDat, std::bind(&RotaryEncoderChannelSelector::encoderRotateCallback, this), CHANGE);

	// displayChannel();



  // Serial.println(name);
  // _name = name;
  // _channel = 0;
  _cluster = cluster;
}

// void RotaryEncoderChannelSelector::attachInterruptHandlers(std::function<void ()> buttonHandler, std::function<void ()> rotateHandler) {
//   Serial.println("RotaryEncoderChannelSelector::attachInterruptHandlers()");
//   attachInterrupt(_pinSw, buttonHandler, CHANGE);
//   attachInterrupt(_pinDat, rotateHandler, CHANGE);
// }

void IRAM_ATTR RotaryEncoderChannelSelector::encoderButtonCallback() {
  Serial.println("encoderButtonCallback()");
  int value = digitalRead(_pinSw);
  Serial.println( value );
}

void IRAM_ATTR RotaryEncoderChannelSelector::encoderRotateCallback() {
  // Serial.println("RotaryEncoderChannelSelector::encoderRotateCallback()");

  // Read the current state of CLK
  int channel = _cluster->getSelectedChannel();
	_currentStateCLK = digitalRead(_pinClk);
  // Serial.print("_currentStateCLK=");
  // Serial.println(_currentStateCLK);

	// If last and current state of CLK are different, then pulse occurred
	// React to only 1 state change to avoid double count
	if (_currentStateCLK != _lastStateCLK  && _currentStateCLK == 1){
  Serial.println("CLK changed");
  Serial.print("channel=");
  Serial.println(channel);
  Serial.print("_cluster->numChannels()=");
  Serial.println(_cluster->numChannels());

		// If the DT state is different than the CLK state then
		// the encoder is rotating CCW so decrement
    // Serial.print("_pinDat=");
    // Serial.println(_pinDat);
    int val = digitalRead(_pinDat);
    // Serial.print("val=");
    // Serial.println(val);
		if (val != _currentStateCLK) {
  // Serial.println("CCW");
			channel--;
			_currentDir ="CCW";
		} else {
  // Serial.println("CW");
			// Encoder is rotating CW so increment
			channel++;
			_currentDir ="CW";
		}
  // Serial.println("rot int 4");
    if (channel < 0) {
      channel = _cluster->numChannels() - 1;
    } else if (channel >= _cluster->numChannels()) {
      channel = 0;
    }
  // Serial.println("rot int 5");
    _cluster->setSelectedChannel(channel);
  // Serial.println("rot int 6");

		Serial.print("Direction: ");
		Serial.print(_currentDir);
		Serial.print(" | New Channel: ");
		Serial.println(channel);

		// displayChannel();
	}

	// Remember last CLK state
	_lastStateCLK = _currentStateCLK;
}



// void RotaryEncoderChannelSelector::updateFromServer(JSONVar data) {
//   Serial.printf("RotaryEncoderChannelSelector::updateFromServer(%s)\n", _name.c_str());
// }

// int RotaryEncoderChannelSelector::currentChannel() {
//   return _channel;
// }


// void RotaryEncoderChannelSelector::inTheLoop(Oldgauge* cluster) {
//   Serial.printf("RotaryEncoderChannelSelector::inTheLoop(%s)\n", _name.c_str());

//   _channel++;
// }

// JSONVar RotaryEncoderChannelSelector::toJSONVar() {
//   JSONVar me;
//   me["currentChannel"] = _channel;
//   return me;
// }