#include <Arduino.h>
#include <Oldgauge.h>
#include <TFT_eSPI.h> 

OG_T_Display::OG_T_Display(String name, TFT_eSPI* tft) : OG_OutputDevice(name) {
  // Serial.print("OG_T_Display::OG_T_Display(");
  // Serial.print(name);
  // Serial.println();
  _name = name;
  // _selector = selector;
  _tft = tft;
}


JSONVar OG_T_Display::toJSONVar() {
  JSONVar me;
  me["v1"]["type"] = "int";
  // me["v1"]["min"] = 0;
  // me["v1"]["max"] = 255;
  return me;
}


void OG_T_Display::updateFromServer(JSONVar data) {
  // Serial.printf("OG_T_Display::updateFromServer(%s)\n", _name.c_str());
  return;

  // // Serial.print("\nDevice ");
  // // Serial.print(_name);
  // // Serial.print(" has data ");
  // // Serial.println(JSON.stringify(data));

  // if (JSON.typeof(data["v1"]) == "number") {
  //   _v1 = data["v1"];
  //   _v1Updated = true;
  // } else {
  //   _v1Updated = false;
  // }

  // if (JSON.typeof(data["v2"]) == "number") {
  //   _v2 = data["v2"];
  //   _v2Updated = true;
  // } else {
  //   _v2Updated = false;
  // }
}

// void OG_T_Display::inTheLoop(Oldgauge *cluster) {
//   Serial.printf("OG_T_Display::inTheLoop(%s)\n", _name.c_str());
// }

void OG_T_Display::show(Oldgauge* cluster, OG_Layout* layout, JSONVar data) {
  // Serial.printf("OG_T_Display::show(%s)\n", _name.c_str());
  // Serial.printf("  channel=%d\n", _selector->currentChannel());

  // _tft->drawString("YARP", 5, 5, 4);

  int BG_COLOR = 0xf7db;
  int fgColor = 0x8430;
  // int fgColor2 = TFT_BLUE;


    int middle = 160;
    // int middle2 = 65;




  JSONVar channelLabel = data["label"];
  _tft->setTextDatum(TL_DATUM);
  _tft->setTextColor(fgColor, BG_COLOR, true);
  // int channel = cluster->getSelectedChannel();
  // _tft->drawString(String(channel), middle + 10, 15, 4);
  String s = channelLabel;
  _tft->drawString(s, 10, 15, 4);


  JSONVar myData = data["data"];
  JSONVar keys = myData.keys();

  // Lets just show the first data value.
  if (keys.length() >= 1) {
    JSONVar metric = myData[keys[0]];
    String label = metric["label"];
    String style = metric["style"];
    int value = metric["value"];

    _tft->setTextDatum(TR_DATUM);
    _tft->setTextColor(fgColor, BG_COLOR, true);
    _tft->drawString(label + ":", middle, 55, 4);
    // _tft->setTextColor(_v2Updated ? TFT_BLUE : TFT_ORANGE, BG_COLOR, true);

    _tft->setTextDatum(TR_DATUM);
    _tft->setTextColor(TFT_BLUE, BG_COLOR, true);
    _tft->drawString("   " + String(value), _tft->getViewportWidth() - 25, 55, 4);
    // Serial.println("SHOWING '" + label + "' AS VALUE " + String(value) + " WITH STYLE " + style);
  }

  if (keys.length() >= 2) {
    JSONVar metric = myData[keys[1]];
    String label = metric["label"];
    String style = metric["style"];
    int value = metric["value"];

    _tft->setTextDatum(TR_DATUM);
    _tft->setTextColor(fgColor, BG_COLOR, true);
    _tft->drawString(label + ":", middle, 90, 4);

    _tft->setTextDatum(TR_DATUM);
    
    _tft->setTextColor(TFT_BLUE, BG_COLOR, true);
    _tft->drawString("   " + String(value), _tft->getViewportWidth() - 25, 90, 4);
    // Serial.println("SHOWING '" + label + "' AS VALUE " + String(value) + " WITH STYLE " + style);
  }




    // // _tft->drawString("channel:", middle, 15, 4);  //string,start x,start y, font weight {1;2;4;6;7;8}
    // _tft->drawString(label, middle, 50, 4);

    // // _tft->drawString("pin:", middle2, 85, 2);
    // // _tft->drawString("mac addr:", middle2, 100, 2);
    // // _tft->drawString("clusterId:", middle2, 115, 2);

    // _tft->setTextDatum(TL_DATUM);
    // _tft->setTextColor(fgColor2, BG_COLOR, true);
    // // _tft->setTextColor(fgColor, BG_COLOR, true);
    // // _tft->setTextColor(TFT_BLACK, BG_COLOR, true);
    // // _tft->drawString("187261  ", middle2 + 5, 85, 2);
    // // _tft->drawString("0a:22:e7:9c:22:eb  ", middle2 + 5, 100, 2);
    // // _tft->drawString("6b6081f3-962f-47aa-af38-64589d72aab5  ", middle2 + 5, 115, 2);

    // _tft->setTextColor(_v1Updated ? TFT_BLUE : TFT_ORANGE, BG_COLOR, true);
    // _tft->drawString(String(value) + "      ", middle + 10, 50, 4);


}

