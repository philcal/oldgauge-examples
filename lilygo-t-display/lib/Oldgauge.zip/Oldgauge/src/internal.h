#include <WiFiManager.h>         //https://github.com/tzapu/WiFiManager

#ifdef ESP32
  #include <SPIFFS.h>
#endif

extern bool shouldSaveConfig;
extern char param_passphrase[50];
extern char param_pin[10];
extern char param_clusterID[128];
void rememberToSaveConfig();
void saveConfigIfNecessary();
void loadConfig();
void saveConfig();

// Captive Portal
extern WiFiManager wm;
extern WiFiManagerParameter passphrase_text_box;
extern WiFiManagerParameter pin_text_box;
extern WiFiManagerParameter clusterID_text_box;
// void initialiseCaptivePortal();
// bool enterConfigModeIfTilted();
