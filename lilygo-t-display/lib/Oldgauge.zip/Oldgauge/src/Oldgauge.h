#include <TFT_eSPI.h>
#include <Arduino_JSON.h>


void initialiseCaptivePortal();
bool enterConfigModeIfTilted();


#define OG_MAX_CHANNELS 10
#define OG_MAX_LAYOUTS 10
#define OG_MAX_DEVICES 10

String getMacaddr();

class Oldgauge;
class OG_Layout;
class OG_OutputDevice;
class ChannelSelector;
class OG_T_Display;
class OG_PwmMeter;

// class Oldgauge {
//   private:
//     int _pinConfigButton;
//     int _pinPairingLed;
//     int _pinErrorLed;
//     Oldgauge* _cluster;

//   public:
//     Oldgauge(int pinConfigButton, int pinPairingLed, int pinErrorLed);
//     void addCluster(Oldgauge* cluster);
//     bool enterConfigModeIfTilted();
//     void inTheLoop();
// };

class Oldgauge {
  public:
    Oldgauge(bool useMockData, int pinConfigButton, int pinPairingLed, int pinErrorLed);
    void addLayout(OG_Layout* layout);
    JSONVar toJSONVar();
    // void setChannelSelector(ChannelSelector* selector);
    void inTheLoop();

    // Channel list
    int numChannels();
    String channelLabel(int channel);

    // Current channel
    int getSelectedChannel();
    int getDisplayedChannel();
    void setSelectedChannel(int channel);
    void channelUp();
    void channelDown();

    void errorBlink(int num);
    bool enterConfigModeIfTilted();
    

  private:
    bool _useMockData;
    int _pinPairingLed;
    int _pinErrorLed;
    int _pinConfigButton;
    OG_Layout* _layouts[OG_MAX_LAYOUTS];
    int _numLayouts = 0;
    // ChannelSelector* _selector = null;

    // int _numChannels = 1;
    // String _channels[OG_MAX_CHANNELS] = { "default" };
    int _selectedChannel = 0;
    int _displayedChannel = 0;
    // int _displayedSubChannel = 0;
    // String _displayedLayout = "";
    JSONVar _displayedData;

    int _previousResetPin = HIGH;


    void showChannel(int channelNo);
};


class OG_Layout {
  public:
    OG_Layout(String name);
    void addOutputDevice(OG_OutputDevice* device);
    String getName();
    JSONVar toJSONVar();
    // void updateFromServer(JSONVar data);
    void show(Oldgauge* cluster, JSONVar data);

  private:
    String _name;
    OG_OutputDevice* _outputs[OG_MAX_DEVICES];
    int _numOutputs = 0;
    OG_OutputDevice* _inputs[OG_MAX_DEVICES];
    int _numInputs = 0;
    OG_OutputDevice* _selector;
};


/*
 *  Channel selector.
 */
class RotaryEncoderChannelSelector {
  public:
    RotaryEncoderChannelSelector(
      Oldgauge* cluster,
      int pinSw, int pinClk, int pinDat,
      std::function<void ()> buttonHandler,
      std::function<void ()> rotateHandler
      // int pinLed1, int pinLed2, int pinLed3, int pinLed4, int pinLed5, int pinLed6
    );
    // void updateFromServer(JSONVar data);
    // void inTheLoop(Oldgauge* cluster);
    // int currentChannel();
    // JSONVar toJSONVar();
    // void attachInterruptHandlers(std::function<void ()> buttonHandler, std::function<void ()> rotateHandler);
    void IRAM_ATTR encoderButtonCallback();
    void IRAM_ATTR encoderRotateCallback();

  private:
    // String _name;
    // int _channel;

    Oldgauge* _cluster;
    int _pinSw;
    int _pinClk;
    int _pinDat;

    // State stuff
    int _currentStateCLK;
    int _lastStateCLK;
    String _currentDir = "";
};

class OG_OutputDevice {
    public:
      OG_OutputDevice(String name);
      virtual JSONVar toJSONVar() = 0;
      virtual void updateFromServer(JSONVar data) = 0;
      // virtual void inTheLoop(Oldgauge* cluster) = 0;
      virtual void show(Oldgauge*, OG_Layout*, JSONVar data) = 0;
      String getName();

    protected:
      // OG_OutputDevice() = default;
      String _name;

    private:
        //void init(String name);
};

class OG_T_Display : public OG_OutputDevice {
  public:
    OG_T_Display(String name, TFT_eSPI* tft);
    JSONVar toJSONVar();
    void updateFromServer(JSONVar data);
    // void inTheLoop(Oldgauge* cluster);
    void show(Oldgauge*, OG_Layout*, JSONVar data);

  private:
    TFT_eSPI* _tft;
    int _v1 = 0;
    int _v2 = 0;
    bool _v1Updated = false;
    bool _v2Updated = false;
};


class OG_PwmMeter: public OG_OutputDevice {
  public:
    OG_PwmMeter(String name, int pwmPin);
    JSONVar toJSONVar();
    void updateFromServer(JSONVar data);
    void show(Oldgauge*, OG_Layout*, JSONVar data);

  private:
    int _v1 = 0;
    // int _v2 = 0;
    bool _v1Updated = false;
    // bool _v2Updated = false;
    int _pwmPin;

    // PWM Config
    const int _pwmChannel = 0; // Selects channel 0
    const int _frequence = 1000; // PWM frequency of 1 KHz
    const int _resolution = 8; // 8-bit resolution, 256 possible values

};



class OG_ChannelSelectionLEDs: public OG_OutputDevice {
  public:
    OG_ChannelSelectionLEDs(Oldgauge* cluster, String name,
    int pinLed1, int pinLed2, int pinLed3, int pinLed4, int pinLed5, int pinLed6);
    JSONVar toJSONVar();
    void updateFromServer(JSONVar data);
    void show(Oldgauge*, OG_Layout*, JSONVar data);

  private:
    Oldgauge* _cluster;
    int _pinLed1;
    int _pinLed2;
    int _pinLed3;
    int _pinLed4;
    int _pinLed5;
    int _pinLed6;
};



/*
        JSONVar myObject = JSON.parse(payload);
  
        // JSON.typeof(jsonVar) can be used to get the type of the var
        if (JSON.typeof(myObject) == "undefined") {
          Serial.println("Parsing input failed!");
          errorBlink(2);
          return;
        }
      
        // Serial.print("JSON object = ");
        // Serial.println(myObject);
      
        // myObject.keys() can be used to get an array of all the keys in the object
        // JSONVar keys = myObject.keys();
      
        if (myObject.hasOwnProperty("metrics")) {
          JSONVar metrics = myObject["metrics"];
*/