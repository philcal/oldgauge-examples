/*
 *  Output device.
 */
#include <Arduino.h>
#include <Oldgauge.h>

OG_OutputDevice::OG_OutputDevice(String name) {
  // Serial.print("OG_OutputDevice::OG_OutputDevice( ");
  // Serial.print(name);
  // Serial.println(")");
  _name = name;
}

String OG_OutputDevice::getName() {
  // Serial.print("OG_OutputDevice::getName(");
  // Serial.print(_name);
  // Serial.println(")");
  return _name;
}
